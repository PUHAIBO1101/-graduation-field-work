<template>
	<view>
		<view class="bg">
		<!-- 对话区域 -->
		<view v-for="(msg, index) in messages" :key="index" :class="msg.role === 'user' ? 'r-dialog-bubble' : 'l-dialog-bubble'">
			<text>{{ msg.content }}</text>
		</view>
		</view>
		<!-- 输入区域 -->
		<view class="submit-layout">
		  <input class="submit-input" placeholder="点击输入，开始聊天吧" v-model="userInput" @confirm="sendMessage"/>
		  <view class="submit-submit" type="submit" size="mini" @click="sendMessage">发送</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInput: "",       // 用户输入
				messages: [],        // 消息记录
				loading: false       // 是否正在加载
			}
		},
		methods: {
			sendMessage() {
				const message = this.userInput.trim();
				if (message === "") {
					return; // 不发送空消息
				}

				// 添加用户消息到消息列表
				this.messages.push({
					role: "user",
					content: message
				});

				// 清空输入框
				this.userInput = "";
				
				// 准备发送给后端的消息记录
				const payload = {
					"messages": this.messages.map(msg => ({
						"role": msg.role,
						"content": msg.content
					})),
					"temperature": 0.95,
					"top_p": 0.8,
					"penalty_score": 1,
					"enable_system_memory": false,
					"disable_search": false,
					"enable_citation": false
				};

				// 设置加载状态
				this.loading = true;

				uni.request({
					url: "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions_pro?access_token=24.654cb76e984112f1ccc277f2656c814b.2592000.1727507836.282335-112166740",
					method: 'POST',
					header: {
						'Content-Type': 'application/json'
					},
					data: JSON.stringify(payload),
					success: (res) => {
						if (res.data && res.data.result) {
							// 添加助手回复到消息列表
							this.messages.push({
								role: "assistant",
								content: res.data.result
							});
						} else {
							console.error("无效的响应数据:", res);
							this.messages.push({
								role: "assistant",
								content: "抱歉，我无法理解您的请求。"
							});
						}
					},
					fail: (err) => {
						console.error("请求失败:", err);
						this.messages.push({
							role: "assistant",
							content: "抱歉，网络错误。请稍后再试。"
						});
					},
					complete: () => {
						// 取消加载状态
						this.loading = false;
					}
				});
			}
		},
		onLoad(option) {
			// 初始化加载逻辑（如果需要）
		}
	}
</script>

<style>
	.bg{
		  width: 100%;
		  height: 89%; /* 80% 的高度 */
		  position: fixed;

		  overflow-y: auto; /* 使内容可滚动 */
	}
.l-dialog-bubble{
	  padding: 50rpx 48rpx;
	  margin: 20rpx 18rpx;
	  width: calc(100% - 36rpx);
	  height: auto;
	  background: #c2dcff;
	  border-radius: 48rpx 48rpx 48rpx 8rpx;
	  box-sizing: border-box;
	  box-shadow:2rpx 2rpx 4rpx 0rpx rgba(74,122,105,0.4);
}
.r-dialog-bubble{
	  padding: 50rpx 48rpx;
	  margin: 30rpx 18rpx;
	  width: calc(100% - 36rpx);
	  height: auto;
	  background: #c2dcff;
	  border-radius: 48rpx 48rpx 8rpx 48rpx ;
	  box-sizing: border-box;
	  box-shadow:2rpx 2rpx 4rpx 0rpx rgba(74,122,105,0.4);
}
.text1{
	display: flex;
	justify-content: center;
	align-items: center;
	font-size: large;
	color: #3abb03;
}
.submit-layout {
  width: 100%;
  position: fixed;
  bottom: 0;
  border-top: 1px solid #ddd;
  padding: 10rpx 0;
  display: flex;
  flex-direction: row;
  align-items: center;
}

.submit-input {
  flex: 1;
  background: #fff;
  margin: 5rpx 10rpx;
  border-radius: 5rpx;
  padding: 15rpx 20rpx;
  color: #333;
  font-size: 30rpx;
}

.submit-submit {
  background-color: #c2dcff;

  font-size: 30rpx;
  border-radius: 10rpx;
  padding: 18rpx 30rpx;
  margin-right: 10rpx;
  text-align: center;
}
</style>

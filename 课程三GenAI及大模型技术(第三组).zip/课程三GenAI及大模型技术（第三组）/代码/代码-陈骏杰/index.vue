<template>
	<view>
		<view class="r-dialog-bubble" v-if='show'>
			{{question}}
		</view>
		<view class="l-dialog-bubble" v-if='show'>
			<text>{{solution}}</text>
		</view>
		
		<view class="submit-layout">
		  <input class="submit-input" placeholder="点击输入，开始聊天吧" v-model="userInput"/>
		  <view class="submit-submit" type="submit" size="mini" @click="sendMessage">发送</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				question:"",
				solution:"",
				show:false
			}
		},
		methods: {
			sendMessage()
			{
				const message = this.userInput;
				this.question=message
				const payload = {
					"messages": [
						{
							"role": "user",
							"content": "测试"
						}
					],
					"temperature": 0.95,
					"top_p": 0.8,
					"penalty_score": 1,
					"enable_system_memory": false,
					"disable_search": false,
					"enable_citation": false
				};
				payload.messages[0].content=message
				let that=this
				that.show=true
				uni.request({
					url: "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions_pro?access_token=24.654cb76e984112f1ccc277f2656c814b.2592000.1727507836.282335-112166740",
					method: 'POST',
					header: {
						'Content-Type': 'application/json'
					},
					data: JSON.stringify(payload),
					success: (res) => {
						console.log(res.data.result);
						that.solution=res.data.result
					},
					fail: (err) => {
						console.error(err);
					}
				});
			}
		},
		
		onLoad(option) {
		}
	}
</script>

<style>
.l-dialog-bubble{
	  padding: 50rpx 48rpx;
	  margin: 20rpx 18rpx;
	  width: calc(100% - 36rpx);
	  height: auto;
	  background: #c2dcff;
	  border-radius: 48rpx 48rpx 48rpx 8rpx;
	  box-sizing: border-box;
	  box-shadow:2rpx 2rpx 4rpx 0rpx rgba(74,122,105,0.4);
}
.r-dialog-bubble{
	  padding: 50rpx 48rpx;
	  margin: 30rpx 18rpx;
	  width: calc(100% - 36rpx);
	  height: auto;
	  background: #c2dcff;
	  border-radius: 48rpx 48rpx 8rpx 48rpx ;
	  box-sizing: border-box;
	  box-shadow:2rpx 2rpx 4rpx 0rpx rgba(74,122,105,0.4);
}
.text1{
	display: flex;
	justify-content: center;
	align-items: center;
	font-size: large;
	color: #3abb03;
}
.submit-layout {
  width: 100%;
  position: fixed;
  bottom: 0;
  border-top: 1px solid #ddd;
  padding: 10rpx 0;
  display: flex;
  flex-direction: row;
  align-items: center;
}

.submit-input {
  flex: 1;
  background: #fff;
  margin: 5rpx 10rpx;
  border-radius: 5rpx;
  padding: 15rpx 20rpx;
  color: #333;
  font-size: 30rpx;
}

.submit-submit {
  background-color: #c2dcff;

  font-size: 30rpx;
  border-radius: 10rpx;
  padding: 18rpx 30rpx;
  margin-right: 10rpx;
  text-align: center;
}
</style>

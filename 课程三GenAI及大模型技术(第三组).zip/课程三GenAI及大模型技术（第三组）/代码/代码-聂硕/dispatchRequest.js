import adapter from '../adapters/index'

export default (config) => adapter(config)
